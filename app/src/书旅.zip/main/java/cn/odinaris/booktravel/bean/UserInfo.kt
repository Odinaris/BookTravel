package cn.odinaris.booktravel.bean

import cn.bmob.v3.BmobUser

class UserInfo : BmobUser(){
    var studentId:String = ""//学号
    var avatarUrl:String = ""//用户头像Url
}